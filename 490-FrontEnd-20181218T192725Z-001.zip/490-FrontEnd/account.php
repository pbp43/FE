<?php
$hostname = 'localhost';
$username = 'testhost';
$password = 'password';
$project = 'userLogin';
?>
